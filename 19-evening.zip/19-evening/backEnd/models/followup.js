const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Business
let Followups = new Schema({
ref:{type: mongoose.Schema.Types.ObjectId,ref:'Lead'},   
status:{type: String},
followup:{type: String},
datetime:{type: String},
nextstep:{type: String},
expectedwalikin:{type: String},
email:{type: String},
},{
    collection: 'followups'
});

module.exports = mongoose.model('Followups', Followups);