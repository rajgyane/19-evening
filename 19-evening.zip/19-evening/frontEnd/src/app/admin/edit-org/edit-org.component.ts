import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { ServicesService} from '../../auth/services.service';
import{ ActivatedRoute,Router} from '@angular/router';
import { MessageboxComponent} from '../messagebox/messagebox.component';
import { MatDialog, MatDialogConfig } from '@angular/material';
import {  FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
const URL = 'http://localhost:4000/business/upload';

@Component({
  selector: 'app-edit-org',
  templateUrl: './edit-org.component.html',
  styleUrls: ['./edit-org.component.css']
})
export class EditOrgComponent implements OnInit {
  org_data:any={};
  angForm: FormGroup;
  status:string;
  uploaded_file_name:string;
  uploaded_status:boolean;
  
  public uploader: FileUploader = new FileUploader({ url: URL, itemAlias: 'photo',allowedMimeType: ['image/png', 'image/gif', 'video/mp4', 'image/jpeg'],maxFileSize: 1024 * 1024 * 1 });
  constructor(private fb: FormBuilder,private ls:ServicesService,private route: ActivatedRoute,
    private router: Router,public dialog: MatDialog) { 
      this.createForm();
    }

  ngOnInit() {
    this.uploaded_status=false;
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false;this.uploaded_status=false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
         console.log('ImageUpload:uploaded:', item, status, response);
         this.uploaded_file_name=JSON.parse(response).newfilename;
         this.uploaded_status=true;
         //console.log(this.uploaded_status);
    };

    this.route.params.subscribe(params => {
      this.ls.editOrg(params['id']).subscribe(res => {
        this.org_data = res;
        this.angForm.patchValue({
          org_status:this.org_data.status
          //select_state(this.lead.country)  
        });
        
        //console.log(this.org_data);
    });
  });
 }
  createForm() {
    this.angForm = this.fb.group({
      full_name_org: ['', Validators.required ],
      org_alise: ['', Validators.required ],
      logo: [''],
      address_of_organization: ['', Validators.required ],
      after_uploaded_file_name:[''],
      org_status:['',Validators.required]

      

    });
  }

  edit_organization_data(org_name,org_alise,upload_image,org_address,org_status)
  {

    this.route.params.subscribe(params => {
      this.ls.updateOrgdata(org_name,org_alise,upload_image,org_address,org_status,params['id']);
      const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
    dialogConfig1.width='300px';
    dialogConfig1.height='250px';

dialogConfig1.data = {
          
            response_data:"Update Data Successfully"
      
          };
          
          //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
          dialogRef.afterClosed().subscribe(result => {
            if(result==true)
            {
              
              //window.location.href = 'admin/list_org';
              this.router.navigate(['admin/list_org']);
              
            }
            }); 
      
 });
 
 
}
    
  


}
