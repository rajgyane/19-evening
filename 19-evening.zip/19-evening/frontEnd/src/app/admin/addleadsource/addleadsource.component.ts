import { Component, OnInit ,Inject, ComponentFactoryResolver} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { MessageboxComponent} from '../messagebox/messagebox.component';
import {LeadSource} from '../../model/lead-source';
import{ ActivatedRoute,Router} from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {ServicesService} from '../../auth/services.service';

@Component({
  selector: 'app-addleadsource',
  templateUrl: './addleadsource.component.html',
  styleUrls: ['./addleadsource.component.css']
})
export class AddleadsourceComponent implements OnInit {
  angForm: FormGroup;
  lead_source_data:LeadSource[]=[];
  response:string;
  constructor( public dialogRef: MatDialogRef<LeadSource>,@Inject(MAT_DIALOG_DATA) public data: any,public fb:FormBuilder,private ls:ServicesService,public dialog: MatDialog,private router: Router
  )
   {this.createForm(); }

  ngOnInit() {
  }
  createForm() {
    this.angForm = this.fb.group({
      
      leadsource: ['', Validators.required ]
      
    });
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  add_leadsource()
  {
    let leadsource=this.angForm.value.leadsource;
    this.ls
    .add_leadsourcedata(leadsource)
    .subscribe((data: LeadSource[]) => {
      const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
    dialogConfig1.width='350px';
    dialogConfig1.height='250px';

 dialogConfig1.data = {
          
            response_data:data
      
          };
          
          
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
      //this.lead_source_data = data;
      //console.log(this.leadsourcedata);
      dialogRef.afterClosed().subscribe(result => {
        if(result==true)
        {
          
          window.location.href = 'admin/lead_source_list';
          
        }
        });
     
      
});


  }

}
