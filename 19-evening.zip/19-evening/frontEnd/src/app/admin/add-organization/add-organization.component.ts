import { Component, OnInit, ComponentFactoryResolver } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {ServicesService} from '../../auth/services.service';
import{ ActivatedRoute,Router} from '@angular/router';
import {  FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
import { MessageboxComponent} from '../messagebox/messagebox.component';
import { MatDialog, MatDialogConfig } from '@angular/material';

const URL = 'http://localhost:4000/business/upload';

@Component({
  selector: 'app-add-organization',
  templateUrl: './add-organization.component.html',
  styleUrls: ['./add-organization.component.css']
})
export class AddOrganizationComponent implements OnInit {
  angForm: FormGroup;
  status:string;
  uploaded_file_name:string;
  uploaded_status:boolean;
  
  public uploader: FileUploader = new FileUploader({ url: URL, itemAlias: 'photo',allowedMimeType: ['image/png', 'image/gif', 'video/mp4', 'image/jpeg'],maxFileSize: 1024 * 1024 * 1 });
  constructor(private fb: FormBuilder,private ls:ServicesService,private route: ActivatedRoute,public dialog: MatDialog,
    private router: Router) { 
      this.createForm();
    }

  ngOnInit() {
    this.uploaded_status=false;
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false;this.uploaded_status=false; };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
         console.log('ImageUpload:uploaded:', item, status, response);
         this.uploaded_file_name=JSON.parse(response).newfilename;
         this.uploaded_status=true;
         //console.log(this.uploaded_status);
    };
 }
  createForm() {
    this.angForm = this.fb.group({
      full_name_org: ['', Validators.required ],
      org_alise: ['', Validators.required ],
      logo: [''],
      address_of_organization: ['', Validators.required ],
      after_uploaded_file_name:['']

      

    });
  }
  add_organization(org_name,org_alise,upload_image,org_address)
  {
    //console.log(org_name+' '+org_alise+ ' '+ upload_image+' '+org_address);
    this.ls.add_organization(org_name,org_alise,upload_image,org_address).subscribe((data: any) => {
        //this.status = data;
        const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
   
dialogConfig1.data = {
          
            response_data:data
      
          };
          dialogConfig1.width='350px';
          dialogConfig1.height='250px';
          //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
          dialogRef.afterClosed().subscribe(result => {
            if(result==true)
            {
              //this.router.navigate(['admin/list_org']);
              //window.location.href = 'admin/lead_source_list';
              
            }
            });
      });
  }

}

