import { Component, OnInit,Inject } from '@angular/core';
import { MAT_DIALOG_DATA ,MatDialogRef} from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {ServicesService} from '../../auth/services.service';
import{ ActivatedRoute,Router} from '@angular/router';
import { List_org} from '../../model/list_org';
import { RoleType} from '../../model/role-type';
import { User }  from '../../model/user';
import { MessageboxComponent} from '../messagebox/messagebox.component';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  angForm: FormGroup;
  org_list_data:List_org[]=[];
  user_role_type:RoleType[]=[];
  user_data:User[]=[];
  error_msg:any;
  email_check_status:any;

  constructor(public dialogRef: MatDialogRef<any>,@Inject(MAT_DIALOG_DATA) public data: any,private fb: FormBuilder,private ls:ServicesService,private route: ActivatedRoute,
  private router: Router,public dialog: MatDialog) {
    this.createForm();
   }
   createForm() {
    this.angForm = this.fb.group({
      
      userename: ['', Validators.required ],
      useremail: ['',Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]) ],
      usertype: ['', Validators.required ],
      password: ['', Validators.required ],
      retypepassword: ['', Validators.required],
      organization: ['', Validators.required],
      
    });
  }

  ngOnInit() {
    this.ls
      .list_org()
      .subscribe((data: List_org[]) => {
        this.org_list_data = data;
        
});
this.ls
      .assign_role_type()
      .subscribe((data: RoleType[]) => {
        this.user_role_type = data;
        //console.log(this.user_role_type);
        
});


  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.angForm.controls[controlName].hasError(errorName);
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  public check_password(p1,p2)
  {
    if(p1==p2)
    {
      return true;
    }
    else{
      return false;
    }
  }
  public check_password_length(p1,p2)
  {
    let p_length1=p1.length;
    let p_length2=p2.length;
    if(p_length1<6)
    {
      return false;
    }
    else if(p_length2<6)
    {
     return false;
    }
  }
  public  check_alloted_mail(useremail)
  {
    let userfullname=this.angForm.value.userename; 
    let usertype=this.angForm.value.usertype;
     let list=usertype.split("-");
     //get user role id and role name..
     let role_id=list[0];
     let role_name=list[1];
     //...................................
     let password=this.angForm.value.password;
     let retypepassword=this.angForm.value.retypepassword;
     let organization=this.angForm.value.organization;
     //check email id is already use..
     
     //check condition for password 
     let password_status=this.check_password(password,retypepassword);
     let password_length=this.check_password_length(password,retypepassword);
     const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
    dialogConfig1.width='350px';
    dialogConfig1.height='250px';
    this.ls
      .check_alloted_mail(useremail)
      .subscribe((data: boolean) => {
        this.email_check_status = data;
        //console.log(data);

        if(data==true)
        {
          //this.error_msg='User Email id already taken !!';
          dialogConfig1.data = {      
            response_data:'User Email id already taken '
         };
          
          
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
        }
        else  if(password_status==false)
     {
       //this.error_msg='Password and Retype Password should match !!';
       dialogConfig1.data = {      
        response_data:'Password and Retype Password should match '
     };
      
      
      const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
     }
     else if(password_length==false)
     {
      //this.error_msg='Password Length Must be six letter !!';
      dialogConfig1.data = {      
        response_data:'Password Length Must be six letter '
     };
      
      
      const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
     }
     else{
      this.error_msg='';
      this.ls
      .create_new_user(useremail,role_id,role_name,password,organization,userfullname)
      .subscribe((data: User[]) => {
        //this.user_data = data;
        dialogConfig1.data = {      
          response_data:data
       };
        
        
        const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
        dialogRef.afterClosed().subscribe(result => {
          if(result==true)
          {
            
            window.location.href = 'admin/user_list';
            
          }
          });
        //console.log(this.user_role_type);
        
});
      

     }
        
        
});



  }
  add_user_list()
    {
      let useremail=this.angForm.value.useremail;
      this.check_alloted_mail(useremail); 
    

    
    }

}
