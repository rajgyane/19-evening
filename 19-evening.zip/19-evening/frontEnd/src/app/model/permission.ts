export class Permission
 {
    org_name:string;
    module_id:string;
    module_status: string;
    role_id:string;
    
}