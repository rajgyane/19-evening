import { BrowserModule, Title } from '@angular/platform-browser';
import {SlimLoadingBarModule} from 'ng2-slim-loading-bar';
import { NgModule } from '@angular/core';
import{ HttpClientModule} from '@angular/common/http';
import{ ReactiveFormsModule,FormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule} from './material/material.module';
import { GoogleChartsModule } from 'angular-google-charts';
import { ChartsModule } from 'ng2-charts';
import { IgxCsvExporterService } from "igniteui-angular";





import {AdminModule} from './admin/admin.module';
import {AuthModule} from './auth/auth.module';
import { httpInterceptorProviders } from './http-interceptors/index';





import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

@NgModule({
  declarations: [AppComponent, PageNotFoundComponent],
  imports: [
    BrowserModule,
    MaterialModule,BrowserAnimationsModule,
    AdminModule, ReactiveFormsModule,FormsModule,GoogleChartsModule,ChartsModule,
    AuthModule,SlimLoadingBarModule,HttpClientModule,
    AppRoutingModule
  ],
  providers: [httpInterceptorProviders,Title,IgxCsvExporterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
